#!/bin/bash
OLDIFS=$IFS
while IFS=' ' read line; do
#     echo $hostname $mac $ipipmi
     IFS=$OLD_IFS
     ip=`echo $line | awk -F" " ' { print $1 } ' `
     host=`echo $line | awk -F" " ' { print $2 } ' `
     echo $ip $host 
     sed -e "s/hostName/${host}/;s/hostnameip/${ip}/g" servers-cfg-template > $host.cfg 
done < servers.lists
